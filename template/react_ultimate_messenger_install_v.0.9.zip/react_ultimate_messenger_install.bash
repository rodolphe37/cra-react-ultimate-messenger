#!/bin/bash
color='\e[96m'
rose='\e[1;31m'
vertfonce='\e[0;32m'
orange='\e[0;33m'
bleuclair='\e[1;34m'
blanc='\e[1;37m'


echo -e "${orange}\xf0\x9f\x98\xba\xf0\x9f\x98\x80 THE INSTALLATION PROCEDURE WILL BEGIN... \xf0\x9f\x98\xba\xf0\x9f\x98\x80"
cd ./
mkdir packages
cd packages
git clone https://github.com/rodolphe37/cra-react-ultimate-messenger.git
cd ..
echo -e "${color}ENTER THE APP NAME HERE \e[97m(my-example-name) ?${blanc}"
read string
echo -e "${rose}START OF THE CREATION OF THE APP..."
npx create-react-app ${string} --template file:./packages/cra-react-ultimate-messenger
echo -e "${vertfonce}INSTALLATION COMPLETED!"
echo -e "${rose}DELETE THE TEMPORARY FOLDER NEEDED FOR THE INSTALLATION..."
rm -rf packages
echo -e "${bleuclair}TEMPORARY FOLDER DELETED !"
echo -e "${color}\xf0\x9f\x98\xba\xf0\x9f\x98\x80 NICE DAY TO YOU, YOUR APP ${string} IS READY TO WORK \xf0\x9f\x98\xba\xf0\x9f\x98\x80"${vertfonce}
while true; do
    read -p "DO YOU WISH TO START THE APP RIGHT NOW?" yn
    case $yn in
        [Yy]* ) cd ./${string}; echo -e "APP INITIALIZATION... !"; npm run initAll; echo -e "STARTING APP... !"; npm run dev; break;;
        [Nn]* ) exit;;
        * ) echo "PLEASE ANSWER YES OR NO";;
    esac
done
