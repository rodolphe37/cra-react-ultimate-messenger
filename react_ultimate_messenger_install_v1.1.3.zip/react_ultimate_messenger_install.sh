#!/bin/bash
color='\e[96m'
rose='\e[1;31m'
vertfonce='\e[0;32m'
orange='\e[0;33m'
bleuclair='\e[1;34m'
blanc='\e[1;37m'
BAR='########################################'   # this is full bar, e.g. 40 chars

# begin of  automatic install process
echo -e "${color}\xf0\x9f\x98\xba\xf0\x9f\x98\x80 THE INSTALLATION PROCEDURE WILL BEGIN... \xf0\x9f\x98\xba\xf0\x9f\x98\x80${orange}"
for i in {1..40}; do
    echo -ne "\r${BAR:0:$i}" # print $i chars of $BAR from 0 position
    sleep .1                 # wait 100ms between "frames"
done
echo ""                        # add a new line at the end
# go to the folder
cd ./
# create temporary folder for installation
mkdir packages
# go to the folder
cd packages
# clone repository
git clone https://github.com/rodolphe37/cra-react-ultimate-messenger.git
# go out to the folder
cd ..
# what name you want for your application
echo -e "${color}ENTER THE APP NAME HERE \e[97m(my-example-name) ?${blanc}"
read string
echo -e "${color}STARTING APP CREATION...${orange}"
for i in {1..40}; do
    echo -ne "\r${BAR:0:$i}" # print $i chars of $BAR from 0 position
    sleep .1                 # wait 100ms between "frames"
done
echo ""                        # add a new line at the end
# create new react app with rum template
npx create-react-app ${string} --template file:./packages/cra-react-ultimate-messenger
echo -e "${color}INSTALLATION COMPLETED!${orange}"
for i in {1..40}; do
    echo -ne "\r${BAR:0:$i}" # print $i chars of $BAR from 0 position
    sleep .1                 # wait 100ms between "frames"
done
echo ""                        # add a new line at the end

echo -e "${color}DELETE THE TEMPORARY FOLDER NEEDED FOR THE INSTALLATION...${orange}"
for i in {1..40}; do
    echo -ne "\r${BAR:0:$i}" # print $i chars of $BAR from 0 position
    sleep .1                 # wait 100ms between "frames"
done
echo ""                        # add a new line at the end
#  remove temporary folder (packages)
rm -rf packages
echo -e "${color}TEMPORARY FOLDER DELETED !${orange}"
for i in {1..40}; do
    echo -ne "\r${BAR:0:$i}" # print $i chars of $BAR from 0 position
    sleep .1                 # wait 100ms between "frames"
done
echo ""                        # add a new line at the end

echo -e "${color}\xf0\x9f\x98\xba\xf0\x9f\x98\x80 NICE DAY TO YOU, YOUR APP ${string} IS READY TO WORK \xf0\x9f\x98\xba\xf0\x9f\x98\x80 ${orange}"
for i in {1..40}; do
    echo -ne "\r${BAR:0:$i}" # print $i chars of $BAR from 0 position
    sleep .1                 # wait 100ms between "frames"
done
echo ""                        # add a new line at the end
echo -e "${color}POST INSTALLATION STEP : ${orange}"
for i in {1..40}; do
    echo -ne "\r${BAR:0:$i}" # print $i chars of $BAR from 0 position
    sleep .1                 # wait 100ms between "frames"
done
echo "${color}"                        # add a new line at the end
# Init app section
while true; do
    read -p "DO YOU WISH TO INITIALIZE THE APP RIGHT NOW?" yn
    case $yn in
        [Yy]* ) cd ./${string}; echo -e "APP INITIALIZATION... !"; npm run initAll; break;;
        [Nn]* ) exit;;
        * ) echo "PLEASE ANSWER YES OR NO";;
    esac
done
for i in {1..40}; do
    echo -ne "\r${BAR:0:$i}" # print $i chars of $BAR from 0 position
    sleep .1                 # wait 100ms between "frames"
done
echo ""                        # add a new line at the end
# nvm section for update node version to recommended version (14.15.1)
while true; do
    read -p "YOU HAVE VSCODE INSTALLED AND YOU WANT TO START WORKING RIGHT NOW?" yn
    case $yn in
        [Yy]* ) echo -e "OPENING YOUR APP IN VSCODE..."; code .; break;;
        [Nn]* ) exit;;
        * ) echo "PLEASE ANSWER YES OR NO";;
    esac
done
for i in {1..40}; do
    echo -ne "\r${BAR:0:$i}" # print $i chars of $BAR from 0 position
    sleep .1                 # wait 100ms between "frames"
done
echo ""                        # add a new line at the end
while true; do
    read -p "DO YOU WISH TO START THE APP RIGHT NOW?" yn
    case $yn in
        [Yy]* )  echo -e "STARTING APP... !"; npm run dev; break;;
        [Nn]* ) exit;;
        * ) echo "PLEASE ANSWER YES OR NO";;
    esac
done
