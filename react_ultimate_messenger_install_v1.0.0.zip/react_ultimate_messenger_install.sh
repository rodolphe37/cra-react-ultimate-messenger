#!/bin/bash
color='\e[96m'
rose='\e[1;31m'
vertfonce='\e[0;32m'
orange='\e[0;33m'
bleuclair='\e[1;34m'
blanc='\e[1;37m'
BAR='########################################'   # this is full bar, e.g. 40 chars


echo -e "${orange}\xf0\x9f\x98\xba\xf0\x9f\x98\x80 THE INSTALLATION PROCEDURE WILL BEGIN... \xf0\x9f\x98\xba\xf0\x9f\x98\x80"
for i in {1..40}; do
    echo -ne "\r${BAR:0:$i}" # print $i chars of $BAR from 0 position
    sleep .1                 # wait 100ms between "frames"
done
echo ""                        # add a new line at the end

cd ./
mkdir packages
cd packages
git clone https://github.com/rodolphe37/cra-react-ultimate-messenger.git
cd ..
echo -e "${color}ENTER THE APP NAME HERE \e[97m(my-example-name) ?${blanc}"
read string
echo -e "${rose}START OF THE CREATION OF THE APP..."
for i in {1..40}; do
    echo -ne "\r${BAR:0:$i}" # print $i chars of $BAR from 0 position
    sleep .1                 # wait 100ms between "frames"
done
echo ""                        # add a new line at the end

npx create-react-app ${string} --template file:./packages/cra-react-ultimate-messenger
echo -e "${vertfonce}INSTALLATION COMPLETED!"
for i in {1..40}; do
    echo -ne "\r${BAR:0:$i}" # print $i chars of $BAR from 0 position
    sleep .1                 # wait 100ms between "frames"
done
echo ""                        # add a new line at the end

echo -e "${rose}DELETE THE TEMPORARY FOLDER NEEDED FOR THE INSTALLATION..."
for i in {1..40}; do
    echo -ne "\r${BAR:0:$i}" # print $i chars of $BAR from 0 position
    sleep .1                 # wait 100ms between "frames"
done
echo ""                        # add a new line at the end

rm -rf packages
echo -e "${bleuclair}TEMPORARY FOLDER DELETED !"
for i in {1..40}; do
    echo -ne "\r${BAR:0:$i}" # print $i chars of $BAR from 0 position
    sleep .1                 # wait 100ms between "frames"
done
echo ""                        # add a new line at the end

echo -e "${color}\xf0\x9f\x98\xba\xf0\x9f\x98\x80 NICE DAY TO YOU, YOUR APP ${string} IS READY TO WORK \xf0\x9f\x98\xba\xf0\x9f\x98\x80 ${vertfonce}"
for i in {1..40}; do
    echo -ne "\r${BAR:0:$i}" # print $i chars of $BAR from 0 position
    sleep .1                 # wait 100ms between "frames"
done
echo ""                        # add a new line at the end

while true; do
    read -p "DO YOU WISH TO INITIALIZE THE APP RIGHT NOW?" yn
    case $yn in
        [Yy]* ) cd ./${string}; echo -e "APP INITIALIZATION... !"; npm run initAll; break;;
        [Nn]* ) exit;;
        * ) echo "PLEASE ANSWER YES OR NO";;
    esac
done
for i in {1..40}; do
    echo -ne "\r${BAR:0:$i}" # print $i chars of $BAR from 0 position
    sleep .1                 # wait 100ms between "frames"
done
echo ""                        # add a new line at the end
while true; do
    read -p "DO YOU WISH TO START THE APP RIGHT NOW?" yn
    case $yn in
        [Yy]* ) echo -e "STARTING APP... !"; npm run dev; break;;
        [Nn]* ) exit;;
        * ) echo "PLEASE ANSWER YES OR NO";;
    esac
done
